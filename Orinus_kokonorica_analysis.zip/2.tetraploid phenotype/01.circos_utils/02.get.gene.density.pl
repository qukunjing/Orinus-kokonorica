#!/usr/bin/perl

use strict;
use warnings;
use POSIX;

my $reffile = shift;
my $infile = shift;

my %info; my %num;

open IN, $infile;
while(<IN>) {
    chomp;
    next if (/^#/);
    my @a = split/\s+/;
    next unless ($a[2] eq "gene");
    $a[8] =~ /ID=(.*)/; my $gene = $1;
    $info{$a[0]}{$gene} = [$a[0], $a[3], $a[4]];
}
close IN;

open REF, $reffile;
while(<REF>) {
    chomp;
    my @a = split/\s+/;
    my $length = $a[1];
    my $chrom = $a[0];
    my $time = int($a[1] / 50000);
    # print "$time\n"; exit;
    my $start = 0; my $end;
    for (my $i = 1; $i <= $time; $i ++) {
	$end = $start + 50000;
	$num{$chrom}{$start}{$end} = 0;
	for my $gene (keys %{$info{$chrom}}) {
	    next unless (${$info{$chrom}{$gene}}[1] >= $start && ${$info{$chrom}{$gene}}[1] < $end);
	    $num{$chrom}{$start}{$end} ++;
	}
	$start = $end;
    }

    # print "$start\n";exit;
    $end = $length;
    $num{$chrom}{$start}{$end} = 0;
    for my $gene (keys %{$info{$chrom}}) {
	next unless (${$info{$chrom}{$gene}}[1] >= $start && ${$info{$chrom}{$gene}}[1] < $end);
	$num{$chrom}{$start}{$end} ++;
    }
}
close REF;

my @chr = qw/LG01 LG02 LG03 LG04 LG05 LG06 LG07 LG08 LG09 LG10 LG11 LG12 LG13 LG14 LG15 LG16 LG17 LG18 LG19 LG20/;

for my $chr (@chr) {
    for my $start (sort {$a<=>$b} keys %{$num{$chr}}) {
	for my $end (keys %{$num{$chr}{$start}}) {
	    print "$chr\t$start\t$end\t$num{$chr}{$start}{$end}\n";
	}
    }
}
