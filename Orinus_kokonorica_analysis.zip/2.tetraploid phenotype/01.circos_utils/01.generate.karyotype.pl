#!/usr/bin/perl

use strict;
use warnings;

my $ref = shift;

my %info;

my @chr = qw/chr01 chr02 chr03 chr04 chr05 chr06 chr07 chr08 chr09 chr10 chr11 chr12 chr13 chr14 chr15 chr16 chr17 chr18 chr19 chr20/;

open REF, $ref;
while(<REF>){
    chomp;
    my @a = split/\t/;
    $info{$a[0]} = $a[1];
}
close REF;

for my $chr (@chr) {
    $chr =~ /chr(.*)/;
    print "chr\t-\t$chr\t$chr\t0\t$info{$chr}\t$chr\n";
}
