#!/usr/bin/perl
use strict;
use warnings;

my $reffile = shift; #gff文件
my $infile = shift;  #共线性文件
my %info;
open G, $reffile;
while(<G>){
    chomp;
    next if (/^#/);
    my @a = split/\s+/;
    next unless ($a[2] eq "gene");

    $a[8] =~ /ID=(.*)/;
    my $name = $1;
    $info{$name} = [$a[0], $a[3], $a[4]];
}
close G;

my %out1;
open IN, $infile;
while(<IN>){
    chomp;
    next if (/^#/);
    s/^\s+//;
    my @a = split/\s+/;
    next unless ($a[2] =~ /Oth/ && $a[3] =~ /Cs/);
    my $out = "${$info{$a[2]}}[0]\t${$info{$a[2]}}[1]\t${$info{$a[2]}}[2]\t${$info{$a[3]}}[0]\t${$info{$a[3]}}[1]\t${$info{$a[3]}}[2]";
    push @{$out1{${$info{$a[2]}}[0]}}, $out;
}
close IN;

my $num = 1;
for my $chr (keys %out1) {
    for my $line (@{$out1{$chr}}){
	print "$line\tcolor=set3-12-qual-$num\n";
    }
    $num ++;
    $num = 1 if ($num > 12);
}
