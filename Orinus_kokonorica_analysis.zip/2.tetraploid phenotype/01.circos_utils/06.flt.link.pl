use strict;
use warnings;

my $file = shift;

open F,$file;

while (<F>){
	chomp;
	my @a = split /\t/;
	if ($a[0] =~ /chr02/ && $a[3] =~ /chr03/){
	print "$_\n";
	}elsif($a[0] =~ /chr18/ && $a[3] =~ /chr19/){
	print "$_\n";
	}elsif($a[0] =~ /chr05/ && $a[3] =~ /chr07/){
	print "$_\n";
	}elsif($a[0] =~ /chr13/ && $a[3] =~ /chr15/){
	print "$_\n";
	}elsif($a[0] =~ /chr01/ && $a[3] =~ /chr04/){
	print "$_\n";
	}elsif($a[0] =~ /chr06/ && $a[3] =~ /chr09/){
	print "$_\n";
	}elsif($a[0] =~ /chr08/ && $a[3] =~ /chr11/){
	print "$_\n";
	}elsif($a[0] =~ /chr12/ && $a[3] =~ /chr16/){
	print "$_\n";
	}elsif($a[0] =~ /chr10/ && $a[3] =~ /chr14/){
	print "$_\n";
	}elsif($a[0] =~ /chr17/ && $a[3] =~ /chr20/){
	print "$_\n";	
	}else{
	next;
	}
}
close F;
