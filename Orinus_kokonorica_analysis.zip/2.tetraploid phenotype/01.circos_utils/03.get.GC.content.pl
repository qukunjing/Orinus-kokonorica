#!/usr/bin/perl

use strict;
use warnings;
use Bio::SeqIO;

my $infile = shift;

my $fa = Bio::SeqIO->new(-file=>$infile, -format=>'fasta');
while(my $seq_obj = $fa -> next_seq) {
    my $id = $seq_obj->id;
    my $seq = $seq_obj->seq;
    my $length = length($seq);
    my $num = int($length / 50000);
    my $start = 0; my $end;
    for (my $i = 1; $i <= $num; $i ++) {
	$end = $start + 50000;
	my $seq = substr($seq, $start, 50000);
	my @num = ($seq =~ /C|G/g);
	my $percent = @num / 50000;
	print "$id\t$start\t$end\t$percent\n";
	$start = $end;
    }
}
