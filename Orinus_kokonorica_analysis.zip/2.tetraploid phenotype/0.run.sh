#Sub-genome typing
 # k-mer
 jellyfish count  -m 21 -s 20G -t 20 -o 21mer_out  -C  <(zcat test_1.fq.gz) <(zcat test_2.fq.gz)
 jellyfish histo -t -o 21mer_out.histo 21mer_out
 genomescope for k-mer distribution map
 
 # circos
 circos -conf circos.conf
 
 # wgdi (ks, colinearity,)
 diamond_blastp.pl All.pep All.pep 200 | sh;
 wgdi -d total.conf;
 wgdi -icl total.conf;
 wgdi -ks total.conf;
 wgdi -bi total.conf;
 wgdi -bk total.conf;
 wgdi -kp total.conf;
 cd ../;
