use strict;
use warnings;
use Bio::SeqIO;

my $file = shift;

my $fa = Bio::SeqIO->new(-file=>"$file",-format=>'fasta');
while(my $seq = $fa->next_seq){
    my $id = $seq->id;
    my $seq = $seq->seq;
    #Oropetium_20150105_00001A
    #if ($id =~ /Oropetium_\d+_\d+A/){
	$id =~ s/A$//;
	#print ">$id\n$seq\n";
    print ">$id\n$seq\n";
}
