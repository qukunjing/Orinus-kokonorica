use strict;
use warnings;
use Bio::SeqIO;

#my @sp=("Sbi","Sit");
my @sp=("OthA","OthB");
my $seqdir=("/data/01/user178/05.Oth/03.Synteny/03.wgdi/00.clean_data");
for my $sp (@sp){
    my %id;
    for my $type ("cds","pep"){
        my $fa=Bio::SeqIO->new(-format=>"fasta",-file=>"$seqdir/$sp.$type.clean.fa");
        while (my $seq=$fa->next_seq){
            my $id=$seq->id;
            my $seq=$seq->seq;
            $id{$id}{$type}=$seq;
        }
    }
    my %gff;
    my %chr;
    open (F,"$seqdir/$sp.gff")||die"$!";
    my $last = "NA";
    my $d = 0;
    while (<F>) {
        chomp;
        next if /^#/;
        my @a=split(/\s+/,$_);
        my $strand="+";
        $strand="-" if $a[2]>$a[3];
        ($a[2],$a[3])=sort{$a<=>$b} ($a[2],$a[3]);
        #if ($sp=~/Oth/){
          #  next unless $a[0]=~/^LG\d+/;
	#}els

#	if ($sp=~/Otho/){
#	    if ($a[0] ne $last){
#		$d += 1;
#		$last = $a[0];
#	    }
#	    $a[0] =~ s/.*/Chr$d/;
#	}

	next if ! exists $id{$a[1]};
        $gff{$a[0]}{$a[1]}{strand}=$strand;
        $gff{$a[0]}{$a[1]}{start}=$a[2];
        $gff{$a[0]}{$a[1]}{end}=$a[3];
    }
    close F;
    open (O,">$sp.wgdi.gff");
    open (O1,">$sp.wgdi.cds");
    open (O2,">$sp.wgdi.pep");
    for my $k1 (sort keys %gff){
        my @k2=sort{$gff{$k1}{$a}{start}<=>$gff{$k1}{$b}{start}} keys %{$gff{$k1}};
        for (my $i=0;$i<@k2;$i++){
            my $j=$i+1;
            my $genenum=sprintf("%0*d",5,$j);
            $genenum="$sp$k1"."g$genenum";
            print O "$k1\t$genenum\t$gff{$k1}{$k2[$i]}{start}\t$gff{$k1}{$k2[$i]}{end}\t$gff{$k1}{$k2[$i]}{strand}\t$j\t$k2[$i]\n";
            my $end=$gff{$k1}{$k2[$i]}{end};
            $chr{$k1}{len}=$end;
            $chr{$k1}{num}++;
            print O1 ">$genenum\n$id{$k2[$i]}{cds}\n";
            print O2 ">$genenum\n$id{$k2[$i]}{pep}\n";
        }
    }
    close O;
    close O1;
    close O2;
    open (O,">$sp.wgdi.lens");
    for my $k1 (sort keys %chr){
        #my @len=sort{$a<=>$b} keys %{$chr{$k1}{len}};
        print O "$k1\t$chr{$k1}{len}\t$chr{$k1}{num}\n";
    }
    close O;
    
}
   
