#将evm的gff的基因重新命名
#Author: Mou Yin

use strict;
use warnings;

my ($in,$out,$species)=@ARGV;
die "perl $0 inGFF outGFF speceis\n" if @ARGV != 3;
my $genenum=0;
my $transnum=0;
my $gene;
my $trans;
open (F,"$in")||die"$!";
open (O,">$out");
print O "##gff-version 3\n";
while (<F>) {
    chomp;
    next if /^#/;
    next if /^\s*$/;
    my @a=split(/\t/,$_);
    my $last=pop @a;
    $a[1]='EVM';
    print O join("\t",@a),"\t";
    if ($a[2] eq 'gene'){
        $genenum++;
        my $outnum=sprintf("%06d",$genenum);
        $gene="$species"."G$outnum";
        print O "ID=$gene\n";
        $transnum=0;
    }elsif($a[2] eq 'mRNA'){
        $transnum++;
        $trans=$gene;
        $trans=~s/G(\d+)/T$1/;
        $trans="$trans.$transnum";
        print O "ID=$trans;Parent=$gene\n";
    }elsif($a[2]=~/UTR|exon/){
        $last=~/\.(\w+);Parent=/;
        print O "ID=$trans.$1;Parent=$trans\n";
    }elsif($a[2] eq 'CDS'){
        print O "ID=cds.$trans;Parent=$trans\n";
    }else{
        die "$_\n";
    }
}
close F;
close O;
