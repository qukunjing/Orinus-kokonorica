#!/usr/bin/env perl
use Getopt::Long;
my ($gff,$genome_fa,$species,$mcscan_type,$gff_type,$id_format,$phase_type,$ath,$flt,$help);
GetOptions(
           'gff|g=s' => \$gff,
           'genome|s=s' => \$genome_fa,
           'prefix|n=s' => \$species,
           'gff_type|gt=s' => \$gff_type,
           'mcscan_type|mt=i' => \$mcscan_type,
           'id_format|if=i' => \$id_format,
           'ath|a=s' => \$ath,
           'flt=i' => \$flt,
           'phase_type|pt=s' => \$phase_type,
           'help|?' => \$help
          );
if(! $gff || ! $genome_fa || $help){
    &print_help;
    exit;
}
$gff_type = "s" if(!$gff_type);
$species = "out" if(!$species);
$id_format = 1 if(!$id_format);
$phase_type = "reord" if(!$phase_type);
$ath = "other" if(!$ath and $gff_type eq "s");
$flt = 1 if($flt eq undef);

use strict;
use warnings;
use Bio::SeqIO;
use Bio::Seq;

sub translate_nucl{
    my $seq=shift;
    my $seq_obj=Bio::Seq->new(-seq=>$seq,-alphabet=>'dna');
    my $pro=$seq_obj->translate;
    $pro=$pro->seq;
    return($pro);
}
my %plastid_gene;
my @plastid_gene =qw/psbA matK rbcL atpB atpE ndhC ndhK ndhJ rps4 ycf3 psaA psaB rps14 psbZ psbC psbD psbM petN rpoB rpoC1 rpoC2 rps2 atpI atpH atpF atpA psbI psbK rps16 accD psaI cemA petA psbJ psbL psbF psbE petL petG psaJ rpl33 rps18 rpl20 rps12 clpP psbB psbT psbN psbH petB petD rpoA rps11 rpl36 rps8 rpl14 rpl16 rps3 rps19rpl rpl23   ycf2    ndhB    rps7    rrn16   rrn23   rrn4.5  rrn5    ycf1    rps15   ndhH    ndhA    ndhI    ndhG    ndhE    psaC    ndhD    ccsA    rpl32   ndhF ccmC    orf104a trnS    trnF    orf150  trnP    cox3    orf271  rp15    cob     orf129  orf152  orf100a orf287  orf202  trnN    trnY    nad3    atp4    rps10 cox1    ccmFc   atp6-1  trnK    orf110a orf110e orf109  trnQ    orf104b trnG    nad4    orf106a trnD    orf114b trnfM-1 nad4L-1 nad6    orf189  nad1    ccmB orf117  orf110b nad7    atp1-1  orf167  orf102  orf160a trnfM-2 rrnL    orf113  orf160b nad4L-2 trnfM-3 orf151  orf261  ccmFn   rps1    nad5    orf101a atp1-2 orf107a orf105a trnH    orf107b trnC    orf100b nad9    orf105b orf110c rrnS    trnW    orf101b orf136a orf103b orf215  orf106b nad2    orf114a atp9    trnM trnE    matR    trnI    orf100c orf136b cox2    orf241  atp1-3  atp6-2  trnfM-4 orf110d atp8    orf145  orf103c orf178  orf103d mttB ndhF    rpl32   ccsA    ndhD    psaC    ndhE    ndhG    ndhI    ndhA    ndhH    rps15   ycf1    ycf68   rps7    ndhB    ycf2    rpl23   rpl2    rps19   rps3 rpl16   rpl14   rps8    rpl36   rps11   rpoA    petD    petB    psbH    psbN    psbT    psbB    clpP    rps12   rpl20   rps18   rpl33   psaJ    petG    petL psbE    psbF    psbL    psbJ    petA    cemA    psaI    accD    psbK    psbI    atpA    atpF    atpH    atpI    rps2    rpoC2   rpoC1   rpoB    petN    psbM psbD    psbC    psbZ    rps14   psaB    psaA    ycf3    rps4    ndhJ    ndhK    ndhC    atpE    atpB    rbcL    matK    psbA psbA    matK    rps16   psbK    psbI    atpA    atpF    atpH    atpI    rps2    rpoC2   rpoC1   rpoB    petN    psbM    psbD    psbC    psbZ    rps14   psaB psaA    ycf3    rps4    ndhJ    ndhK    ndhC    atpE    atpB    rbcL    accD    psaI    ycf4    cemA    petA    psbJ    psbL    psbF    psbE    petL    petG psaJ    rpl33   rps18   rpl20   rps12   clpP    psbB    psbT    psbN    psbH    petB    petD    rpoA    rps11   rpl36   rps8    rpl14   rpl16   rps3    rpl22 rps19   rpl2    rpl23   ycf2    ndhB    rps7    ycf1    ndhF    rpl32   ccsA    ndhD    psaC    ndhE    ndhG    ndhI    ndhA    ndhH    rps15   orf103a-2 orf172-1   orf103a-1 orf103a-3   orf172-2   orf172-3   orf139-1  orf139-2  infA/;
$plastid_gene{$_}++ foreach(@plastid_gene);

open(I, $gff) || die "Can't open GFF file!\n";
my %len;
my %judge;
my $no=0;
print "Deal gff file.\n";
if($mcscan_type){
    if($mcscan_type == 2){
        open(MX,">$species.mcscanx.gff");
        print "Your choice is printing McScanX GFF!\n";
    }elsif($mcscan_type == 3){
        open(MP,">$species.mcscan_python.gff");
        print "Your choice is printing McScan_python GFF!\n";
    }elsif ($mcscan_type == 1) {
        open(MX,">$species.mcscanx.gff");
        open(MP,">$species.mcscan_python.gff");
        print "Your choice is printing McScanX and McScan_python GFF!\n";
    }else{
        die "Your --mcscan_type was error!\n";
    }
}
my $all_gene_num; my %tmp; my %transmit_id;
while(<I>){
    chomp;
    next if(/^#/);
    next if(/^\s*$/);
    my @a=split(/\t+/);
    $tmp{$a[2]}++;
    $all_gene_num++ if($a[2] eq "gene");
    $all_gene_num++ if($a[2] eq "mRNA" and !exists $tmp{gene});
    if($gff_type eq "sp"){
        if($a[2] eq "mRNA"){
            $a[8] =~ /(Parent|Accession)=([^;]+)/; my $tmp1 = $2; #$tmp1 =~ s/\.\d+$//;
            unless($tmp1){$a[8] =~ /Name=([^;]+)/; $tmp1 = $1;}
            if($a[8] =~ /Parent_Accession=/){
	$a[8] =~ /Parent_Accession=([^;]+)/; $transmit_id{$tmp1} = $1;
            }else{
	$a[8] =~ /ID=([^;]+)/; my $tmp2 = $1; $transmit_id{$tmp2} = $tmp1;
            }
        }
    }
    if($mcscan_type){
        if($a[8] =~ /gene_biotype=protein_coding/ or $a[2] eq "gene"){
            my $id;
            if($ath){
	if($ath =~ /ath/i){
	    if($a[8] =~ /locus_tag=([^;]+)/){
	        next if($1=~/Arth|DA397/);
	        $id = $1;
	    }
	}else{
	    if ($a[8] =~ /gene=([^;]+)/) {
	        $id = $1;
	    }elsif ($a[8] =~ /locus_tag=([^;]+)/) {
	        $id = $1;
	    }else{
	        $a[8] =~ /Name|Parent=([^;]+)/; $id = $1;
	    }
	}
            }else {
	if($a[2] eq "gene"){
	    if($a[8] =~ /Accession=([^;]+)/){
	        $id = $1;
	    }elsif($a[8] =~ /Parent|Name/){
	        $a[8] =~ /Parent|Name=([^;]+)/;
	        $id = $1;
	    }else{
	        $a[8] =~ /ID=(\S+)/; $id = $1;
	    }
	}
            }
            next unless($id);
            if($mcscan_type == 2 and FltPlastidGene($id)){
	if($a[2] eq "gene"){
	    print MX "$a[0]\t$id\t$a[3]\t$a[4]\n";
	}
            }elsif($mcscan_type == 3 and FltPlastidGene($id)){
	if($a[2] eq "gene"){
	    print MP "$a[0]\t$id\t$a[3]\t$a[4]\t$a[6]\t$a[7]\n";
	}
            }elsif ($mcscan_type == 1 and FltPlastidGene($id)) {
	if($a[2] eq "gene"){
	    print MX "$a[0]\t$id\t$a[3]\t$a[4]\n";
	    print MP "$a[0]\t$a[3]\t$a[4]\t$id\t$a[6]\t0\n";
	}
            }else{next;}
        }
    }
    next unless($a[2] eq "CDS");
    my ($chr,$start,$end,$phase,$name)=($a[0],$a[3],$a[4],$a[6],$a[8]);
    my $mrna; my $gene;
    if($gff_type eq "s"){
        if($name =~ /(protein_id|Alias)=/){
            $name =~ /(protein_id|Alias)=([^;]+)/;
            $mrna = $2;
        }else{
            $name =~ /(Parent|orig_transcript_id|transcript_id|Name)=([^;]+)/;
            $mrna = $2;
        }
        if($ath =~ /ath/i){
            if($name=~/locus_tag=([^;]+)/){
	next if($1 =~ /Arth|DA397/);
	$gene = $1;
            }
        }else{
            if($name=~/gene=([^;]+)/) {
	$gene = $1;
            }elsif ($name=~/locus_tag=/ and $name !~ /gene=/) {
	$name=~/(locus_tag)=([^;]+)/;
	$gene=$2;
            }elsif($name=~/Alias=/){
	$name=~/(Alias)=([^;]+)/;
	$gene=$2;
            }else{
	$name=~/(Name)=([^;]+)/;
	$gene=$2;
            }
        }
        $gene = $mrna unless ($gene);
    }elsif($gff_type eq "o"){
        if($name =~ /Alias=/){
            $name =~ /Alias=([^;]+)/;
            $mrna = $1; my $tmp = $mrna; $mrna=~s/\r+//;
            $tmp =~ /(\S+)\.\d\.v\d\.\d/; $gene = $1;
        }elsif ($name =~ /protein_id=/) {
            $name =~ /protein_id=([^;]+)/;
            my $tmp = $mrna = $1; $tmp =~/(\S+)\.\d+/; $gene = $1;
        }else{
            $name =~ /Parent=([^;]+)/;
            $mrna = $1; my $tmp = $mrna; $mrna=~s/\r+//;
            $tmp =~ /(\S+)(\.mRNA\d+|\.T\d+|\.t\d+|-RA|\.v\d+\.\d+|-mRNA-\d+)?$/i; $gene = $1;
            $gene = $mrna unless($gene);
        }
    }elsif ($gff_type eq "sp") {
        if($name =~ /Parent_Accession=/){
            $name =~ /Parent_Accession=([^;]+)/; $mrna = $1;
        }else{
            $name =~ /Parent=([^;]+)/; $mrna = $1;
        }
        $gene = $transmit_id{$mrna};#my $t = $mrna; $t =~ /(\S+)\.\d+/; $gene = $1;
        $gene =~ s/gene:// if($gene =~ /gene:/); $mrna =~ s/transcript:// if($mrna =~ /transcript:/);
    }else{die "Your --gff_type $gff_type option is error!\n";}
    $gene =~ s/\s+//g;
    my $tmp_id = $gene;
    next if(FltPlastidGene($tmp_id) and $flt);
    if(!exists $judge{$tmp_id}){
        $judge{$tmp_id}++;
        $no++;
    }
    my $cds_len = $end-$start+1; $start--;
    push(@{$len{$chr}{$no}{$gene}{$mrna}{$phase}},"$start\t$cds_len");
    #print "$gene\t$start\t$cds_len\n";
}close I;
if($mcscan_type){if($mcscan_type == 2){close MX;}elsif($mcscan_type == 3){close MP;}elsif ($mcscan_type == 1) {close MX;close MP;}else{next;}}
print "The gene number of total in the genome is $no.\n";
%judge=();

my %delete_splice;
my %new_len;
my %repeat_gene;
print "Deleting the splice by the most long seq!\n";
my $fa=Bio::SeqIO->new(-file=>"$genome_fa",-format=>'fasta');
while(my $obj=$fa->next_seq){
    my $chr= $obj -> id;
    $chr =~ s/(ref\|)(\S+)\|/$2/;
    my $seq= $obj -> seq;
    $chr = "lcl|".$chr if(!exists $len{$chr});
    $chr =~ s/lcl\|// if(!exists $len{$chr});
    print STDERR "Warning: No gene modle was found at the $chr.\nPlease You manual check the gff file.\n" if(!exists $len{$chr});
    print STDOUT "Dealing Chr or Scaffold ($chr) Sequence!\n";
    next if(!exists $len{$chr});
    foreach my $num(sort {$a<=>$b} keys %{$len{$chr}}){
        foreach my $gene(keys %{$len{$chr}{$num}}){
            $repeat_gene{$gene}++;
            my $n = 0; print STDOUT "$gene\t";
            foreach my $mrna(keys %{$len{$chr}{$num}{$gene}}){
	foreach my $phase(keys %{$len{$chr}{$num}{$gene}{$mrna}}){
	    my $cds;
	    for(@{$len{$chr}{$num}{$gene}{$mrna}{$phase}}){
	        my @a = split/\s+/,$_;
	        my $fragmentary = substr($seq, $a[0], $a[1]);
	        if($phase eq "-" and $phase_type eq "reord"){
	            $fragmentary = reverse($fragmentary);
	        }
	        $cds .= $fragmentary;
	    }
	    if($phase eq "-"){
	        if($phase_type eq "reord"){
	            $cds =~ tr/ATCGatcg/TAGCtagc/;
	        }else{
	            $cds = reverse($cds); $cds =~ tr/ATCGatcg/TAGCtagc/;
	        }
	    }
	    $new_len{$gene}{$mrna} = $cds;
	    my $len = length($cds);
	    print STDOUT "$mrna => $len\t";
	    if($len > $n){
	        $n = $len;
	        $delete_splice{$num}{$gene} = $mrna;
	    }
	}
            }
        }
        print STDOUT "\n";
    }
    $seq = undef;
}
$fa = undef;
%len = ();
print "Printing the cds and pep file!\n";
open(O,">$species.cds.fa");
open(E,">$species.pep.fa");
open(AC,">$species.unfiltered.cds.fa");
open(AP,">$species.unfiltered.pep.fa");
open(D,">$species.error.cds.fa");
open(P,">$species.error.pep.fa");
my $filtrated = 0; my %j;
for my $num(sort {$a<=>$b} keys %delete_splice){
    for my $gene(keys %{$delete_splice{$num}}){
        my $tmp = $gene;
        if($repeat_gene{$tmp}>=2){
            $j{$gene}++;
            $tmp .= ".c$j{$gene}";
        }
        my $seq = $new_len{$gene}{$delete_splice{$num}{$gene}};
        next if(length ($seq) == 0);
        my $pep = translate_nucl($seq);
        if($id_format){
            if($id_format == 1){
	print AC ">$tmp\n$seq\n";
	print AP ">$tmp\n$pep\n";
            }else{
	print AC ">$delete_splice{$num}{$gene} $tmp\n$seq\n";print AP ">$delete_splice{$num}{$gene} $tmp\n$pep\n";
            }
        }
        if(FiltratCDS($seq)){
            my $pep = translate_nucl($seq);
            if($id_format){
	if($id_format == 1){
	    print O ">$tmp\n$seq\n";
	    print E ">$tmp\n$pep\n";
	}else{
	    print O ">$delete_splice{$num}{$gene} $tmp\n$seq\n";print E ">$delete_splice{$num}{$gene} $tmp\n$pep\n";
	}
            }
        }else{
            print "$tmp\t$delete_splice{$num}{$gene} is error or fragmentary gene.\n";
            $filtrated++;
            my $pep = translate_nucl($seq);
            if($id_format){
	if($id_format == 1){
	    print D ">$tmp\n$seq\n";
	    print P ">$tmp\n$pep\n";
	}else{
	    print D ">$delete_splice{$num}{$gene} $tmp\n$seq\n";print P ">$delete_splice{$num}{$gene} $tmp\n$pep\n";
	}
            }
        }
    }
}
close O;close E;close D;close P;close AC;close AP;
print "Warning: The filtrated gene num is $filtrated.\n";
if($all_gene_num){
    my $noncoding = $all_gene_num - $no;
    print "All gene number is $all_gene_num.\nProtein_coding gene number is $no.\nNonCoding gene number is $noncoding\n";
}
print "Done!\nPlease you see your result file!\n";
print "$species.cds.fa\n$species.pep.fa\n$species.unfiltrated.cds.fa\n$species.unfiltrated.pep.fa\n$species.error.cds.fa\n$species.error.pep.fa\n";

sub FiltratCDS{
    my $seq = shift;
    my $length=length $seq;
    my $a = $length % 3;
    my $pep = translate_nucl($seq); my $j = 0;
    $j = 1 if($pep =~ /[A-Z]+\*+[A-Z]+/);
    #unfilter NNN
    if($a == 0 and $j == 0){
        return 1;
    }else{
        return 0;
    }
}

sub FltPlastidGene{
    my $id = shift;
    if(exists $plastid_gene{$id}){
        return 1;
    }else{
        return 0;
    }
}


sub print_help{
    print STDERR<<EOF;

gff2cdspep (v2.0)

Usage: perl $0 --gff <gff3_file> --genome <genome.fna file> --prefix <species name abbr> --gff_type <sp> --id_format <1> --phase_type <reord>

Options:
        required:
        --gff|g          gff3 file.
        --genome|s       genome fna.
        options:
        --prefix|n       Abbreviation or full name of the species name, Default: out.
        --gff_type|gt    Gff file type. The gff from NCBI is s, general gff is o, phytozome gff is sp, Default: o.
        --id_format|if   ID format of CDS and PEP files. Select 1 or 2, 1 mean to only use gene name, 2 to use transcript name and gene name, Default: 1.
        --phase_type|pt  When gff phase row is -, the gene cds position order have two types (ord (low to high) and reord (high to low)). Default: reord.
        --mcscan_type|mt Option 1,2,3, if select it, 1 mean to print McscanX and McScan_python need gff and bed, 2 mean to only print McscanX need gff, 3 mean to only print McScan_python need bed. Default: NA.
        --ath|a          Is it Ath? Select ath or other, when gff from NCBI. Default: other, when --gff_type=s. --ath=NA, when --gff_type=o or sp.
        --flt     Whether filter chloroplast genes(0 or 1), default: 1.
        --help           print help information.
        The seqfile have six:
                            The filtered file:     species.cds.fa species.pep.fa
                            The unfiltered file:   species.unfiltered.cds.fa species.unfiltered.pep.fa
                            The error cds file:    species.error.cds.fa species.error.pep.fa

  ** The Chr or Scaffold sequence IDs within the gff3 and genome.fna files must be same (The Chr ID beginning with lcl| is allowed in genome file.)!
EOF
}
