#!/usr/bin/perl

use strict;
use warnings;
use Bio::SeqIO;

my $file = shift;

my $sum_GC_num=0;
my $sum_len=0;
my $sum_GC_content;
my %count;

open (R,">Whole_genome_GC_content.txt") || die ($!);
open (O,">per_Scaffold_GC_content.txt") || die($!);

my $fa = Bio::SeqIO->new(-file=>"$file",-format=>'fasta');
while(my $seq = $fa->next_seq){
    my $id = $seq->id;
    my $seq = $seq->seq;                    #Bio::SeqIO的用法

    my @a = split//,$seq;
    my $num=0;
    foreach my $code(@a){
        if ($code =~ m/G|C/){
            $num++;                         #每条Scaffold的GC数量
        }else{
            next;
        }
    }
    my $len = length $seq;                  #每条Scaffold的长度
    my $GC_per = $num/$len;                 #每条Scaffold的GC含量
    $sum_len = $len + $sum_len;             #全基因组总长
    $sum_GC_num += $num;                    #全基因组的GC数量
    print O "$id\t$len\t$num\t$GC_per\n";   #序列ID 长度 GC数量 GC含量
}
$sum_GC_content = $sum_GC_num/$sum_len;     #全基因组的GC含量
print R "Whole genome lenth: $sum_len\nWhole genome GC number: $sum_GC_num\nWhole genome GC content: $sum_GC_content\n";
close O;
close R;
