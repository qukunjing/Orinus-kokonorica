#!/usr/bin/perl

use strict;
use warnings;
use Bio::SeqIO;

my $fasta;
my $file = shift;

$file =~ /\/.*\/(.*)/g;
my $filename =$1;
my %len;

open (O,">N50_of_Scaffolds.txt") || die ($!);
$fasta = Bio::SeqIO ->new (-file =>$file,-format=>'fasta');
while (my $seq_obj = $fasta -> next_seq ){
      my $name = $seq_obj -> id;
      my $seq = $seq_obj -> seq;
      my $length = $seq_obj -> length;
      $len{$name} = $length;            #构建一个名为len的哈希：键为序列的id，值为序列的长度
  }

my @sort_hash = sort {$len{$a}<=>$len{$b}}(keys %len); # <=> 检查两个数是否想等；现在@sort_hash的内容为序列的id，即哈希len的键
my $seq_num = @sort_hash;                              #得到序列的数量

my $whole_length = 0;

foreach my $hash_key(@sort_hash){   #循环数组sort_hash，即循环序列的id
    chomp $hash_key;                
    $whole_length += $len{$hash_key};   #每条序列长度依次相加，得到基因组的大小
}

my $half_len =  $whole_length/2;        #基因组大小的一半
my $number = 0;
foreach my $hash(@sort_hash){        #循环数组sort_hash，即循环序列的id
    $number += $len{$hash};          #令$number等于序列相加，这里$hash代表的是序列的id，而哈希len的键为序列的id，值为序列的长度，因此得到序列依次相加的结果
    if($number >= $half_len){       #如果当序列相加的值达到基因组大小的一半时，输出该序列的id
        print O " the N50 of contigs/scaffolds is $len{$hash} ";
        exit;
    }
}
close O;
