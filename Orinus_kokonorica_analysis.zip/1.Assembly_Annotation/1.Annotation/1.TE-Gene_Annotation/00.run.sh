# Repeat_annotion
perl gene_predict.v2.pl --config gene_annotation_masked.config --step 1
sh 02.repeat_prediction.sh

# Gene prediction
perl gene_predict.v2.pl --config gene_annotation_masked.config --step 2
sh 03.gene_predict.01.abinitio.sh
sh 03.gene_predict.02.homologs.sh
sh 03.gene_predict.04.EVM.sh