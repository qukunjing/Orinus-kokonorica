#!/usr/bin/perl
use strict;
use warnings;
use Getopt::Long;
use Cwd 'abs_path';
use Bio::SeqIO;

### Created by Yang Yongzhi. 2019.12.10 ###

my ($config,$step);
GetOptions(
           'config=s' => \$config,
           'step=s' => \$step,
          );
if ((! $config) || (! $step)){
    &print_help;
    exit;
}

my %config=&read_conf;
my $base=abs_path($0);
$base=~s/\/gene_predict.v2.pl$// or die "wrong perl script name of $0\n";

#$config{genome}=abs_path("$config{genome}");
my $tmpgenome=$config{genome};
$tmpgenome=~s/^\S+\/([^\/]+)$/$1/ or die "error 1: $config{genome}\n";

# split genome and masked genome
my @tmpsplit_fa;
push @tmpsplit_fa,$config{genome};
if (exists $config{masked_genome}){
    if (-e "$config{masked_genome}"){
	#$config{masked_genome}=abs_path($config{masked_genome});
	push @tmpsplit_fa,$config{masked_genome};
    }
}
for my $tmpsplit_fa (@tmpsplit_fa){
    `perl $base/utils/split_fasta.pl $tmpsplit_fa $tmpsplit_fa-split no`;# if ! -e "$tmpsplit_fa-split";
}

if ($step == 1){
    ## Repeat
    `mkdir 02.repeat_prediction` if (! -e "02.repeat_prediction");
    open (REP,">02.repeat_prediction.sh");
    ### repeatmodeler
    my $tmpdir="02.repeat_prediction/01.repeatmodeler";
    `mkdir $tmpdir` if (! -e "$tmpdir");
    print REP "cd $tmpdir ; sh 00.running.sh; cd ../../\n";
    open (O,">$tmpdir/00.running.sh")||die"$!";
    `ln -s $config{genome} $tmpdir/`;
    print O "$config{BuildDatabase} -name $config{species_abbreviation} $tmpgenome
$config{RepeatModeler} -pa $config{threads} -database $config{species_abbreviation}
ln -s RM*/consensi.fa.classified custom.lib
$config{RepeatMasker} -pa $config{threads} -lib ./custom.lib $tmpgenome
perl $base/utils/ConvertRepeatMasker2gff.pl $tmpgenome.out Denovo.gff Denovo\n";
    close O;
    ### RepeatMasker
    $tmpdir="02.repeat_prediction/02.repeatmasker";
    `mkdir $tmpdir` if (! -e "$tmpdir");
    print REP "cd $tmpdir ; sh 00.running.sh; cd ../../\n";
    open (O,">$tmpdir/00.running.sh")||die"$!";
    `ln -s $config{genome} $tmpdir/`;
    print O "$config{RepeatMasker} -pa $config{threads} -pa $config{threads} -nolow -norna -no_is -gff -species $config{repeat_species} $tmpgenome
perl $base/utils/ConvertRepeatMasker2gff.pl $tmpgenome.out TE.gff TE";
    close O;
    ### RepeatProteinMask
    $tmpdir="02.repeat_prediction/03.repeatproteinmask";
    `mkdir $tmpdir` if (! -e "$tmpdir");
    print REP "cd $tmpdir ; sh 00.running.sh; cd ../../\n";
    open (O,">$tmpdir/00.running.sh")||die"$!";
    `ln -s $config{genome} $tmpdir/`;
    print O "$base/utils/split_fasta.pl $tmpgenome split_by_scaffold 100000
for i in split_by_scaffold/* ; do echo $config{RepeatProteinMask} -noLowSimple -pvalue 1e-04 \$i ; done > 02.split.running.sh
parallel -j $config{threads} < 02.split.running.sh
cat split_by_scaffold/*annot > $tmpgenome.repeatproteinmasker.annot
rm -r split_by_scaffold
perl $base/utils/ConvertRepeatMasker2gff.pl $tmpgenome.repeatproteinmasker.annot TP.gff TP\n";
    close O;
    ### TRF
    $tmpdir="02.repeat_prediction/04.trf";
    `mkdir $tmpdir` if (! -e "$tmpdir");
    print REP "cd $tmpdir ; sh 00.running.sh; cd ../../\n";
    open (O,">$tmpdir/00.running.sh")||die"$!";
    `ln -s $config{genome} $tmpdir/`;
    print O "$config{trf} $tmpgenome 2 7 7 80 10 50 2000 -d -h
perl $base/utils/ConvertTrf2Gff.pl $tmpgenome.2.7.7.80.10.50.2000.dat $tmpgenome.trf.gff\n";
    close O;
    ### Merge
    $tmpdir="02.repeat_prediction/05.merge";
    `mkdir $tmpdir` if (! -e "$tmpdir");
    print REP "cd $tmpdir ; sh 00.running.sh; cd ../../\n";
    open (O,">$tmpdir/00.running.sh")||die"$!";
    `ln -s $config{genome} $tmpdir/`;
    print O "cd $tmpdir
ln -s ../01.repeatmodeler/Denovo.gff .
ln -s ../02.repeatmasker/TE.gff .
ln -s ../03.repeatproteinmask/TP.gff .
ln -s ../04.trf/$tmpgenome.trf.gff .
cat Denovo.gff TE.gff TP.gff| grep -v -P \"^#\" | cut -f 1,4,5 | sort -k1,1 -k2,2n -k3,3n > All.repeat.bed
bedtools merge -i All.repeat.bed > All.repeat.merge.bed
bedtools maskfasta -fi $tmpgenome -bed All.repeat.merge.bed -fo $tmpgenome.mask
";
    close REP;
        
    print "!!!Step 1: Creating repeat annotation associated files done. You can just typing \"sh ./02.repeat_prediction.sh\" or split the sh command and running by yourself!!\n";
}elsif($step == 2){
    ## gene prediction
    open (AB,">03.gene_predict.01.abinitio.sh");
    my $tmpdir="03.gene_predict";
    `mkdir $tmpdir` if (! -e "$tmpdir");
    ### ab-initio
    $tmpdir="03.gene_predict/01.abinitio";
    `mkdir $tmpdir` if (! -e "$tmpdir");
    #### augustus
    $tmpdir="03.gene_predict/01.abinitio/augustus";
    `mkdir $tmpdir` if (! -e "$tmpdir");
    `mkdir $tmpdir/augustus_results` if (! -e "$tmpdir/augustus_results");
    `mkdir $tmpdir/augustus_temp` if (! -e "$tmpdir/augustus_temp");
    `perl $base/utils/run.augustus.predict.pl $config{masked_genome}-split $tmpdir $config{augustus} $config{augustus_train} $base`;
    print AB "##ab-initio\n\n###augustus\nparallel -j $config{threads} < 03.gene_predict/01.abinitio/augustus/00.running.sh ; parallel -j $config{threads} < 03.gene_predict/01.abinitio/augustus/01.converting.sh\n";
    #### genscan
    $tmpdir="03.gene_predict/01.abinitio/genscan";
    `mkdir -p $tmpdir` if (! -e "$tmpdir");
    `mkdir $tmpdir/genscan_results` if (! -e "$tmpdir/genscan_results");
    `mkdir $tmpdir/genscan_temp` if (! -e "$tmpdir/genscan_temp");
    `perl $base/utils/genscan.split.window.step.pl $config{genscan_train} $config{genscan} $base/utils $config{masked_genome}-split $tmpdir`;
    print AB "###genscan\nparallel -j $config{threads} < 03.gene_predict/01.abinitio/genscan/00.running.sh ; parallel -j $config{threads} < 03.gene_predict/01.abinitio/genscan/01.converting.sh\n";
    ### glimmerhmm
    $tmpdir="03.gene_predict/01.abinitio/glimmerhmm";
    `mkdir -p $tmpdir` if (! -e "$tmpdir");
    `mkdir $tmpdir/glimmerhmm_results` if (! -e "$tmpdir/glimmerhmm_results");
    `perl $base/utils/run.glimmerhmm.predict.pl $config{masked_genome}-split $tmpdir/glimmerhmm_results $config{glimmerhmm} $config{glimmerhmm_train} $base/utils/ConvertFormat_glimmerhmm.pl > 03.gene_predict/01.abinitio/glimmerhmm/00.running.sh`;
    print AB "###glimmerhmm\nparallel -j $config{threads} < 03.gene_predict/01.abinitio/glimmerhmm/00.running.sh\n";
    close AB;
    ### homologs
    open (HO,">03.gene_predict.02.homologs.sh");
    $tmpdir="03.gene_predict/02.homologs/GeMoMa";
    `mkdir -p $tmpdir` if (! -e "$tmpdir");
    $config{homologs_dir}=abs_path($config{homologs_dir});
    my @homologs_species=split(/;/,$config{homologs_species});
    open (HOMOSH,">03.gene_predict/02.homologs/GeMoMa/00.running.sh");
    for my $homologs_species (@homologs_species){
	print HOMOSH "java -jar $config{gemoma} CLI GeMoMaPipeline threads=$config{threads} t=$config{genome} s=own g=$config{homologs_dir}/$homologs_species.genome.fa a=$config{homologs_dir}/$homologs_species.genomic.gff outdir=03.gene_predict/02.homologs/GeMoMa/$homologs_species.results AnnotationFinalizer.r=NO tblastn=false ; perl $base/utils/ConvertFormat_GeMoMa.pl 03.gene_predict/02.homologs/GeMoMa/$homologs_species.results/final_annotation.gff\n";
    }
    close HOMOSH;
    print HO "\n##homologs\nsh 03.gene_predict/02.homologs/GeMoMa/00.running.sh\n";
    close HO;
    ### EVM
    open (EVM,">03.gene_predict.04.EVM.sh");
    $tmpdir="03.gene_predict/04.evm";
    `mkdir -p $tmpdir` if (! -e "$tmpdir");
    #### prepare and run
    my $trans="NA";
    $trans=$config{rna_seq_dir} if exists $config{rna_seq_dir};
    print EVM "$base/utils/EVM.prepare.pl $config{EVM} 03.gene_predict/01.abinitio 03.gene_predict/02.homologs/GeMoMa NA $config{genome}-split 03.gene_predict/04.evm\n";
    print EVM "$base/utils/EVM.run.cmd.pl $config{EVM} $config{genome}-split 03.gene_predict/04.evm $base/utils > 03.gene_predict/04.evm/01.split_prepare.sh\n";
    print EVM "parallel -j $config{threads} < 03.gene_predict/04.evm/01.split_prepare.sh\n";
    print EVM "cat 03.gene_predict/04.evm/evm_for_each_chr/*/split_evm_running.sh > 03.gene_predict/04.evm/02.split_run.sh\n";
    print EVM "parallel -j $config{threads} < 03.gene_predict/04.evm/02.split_run.sh\n";
    print EVM "cat 03.gene_predict/04.evm/evm_for_each_chr/*/commands.list > 03.gene_predict/04.evm/03.running.sh\n";
    print EVM "parallel -j $config{threads} < 03.gene_predict/04.evm/03.running.sh\n";
    print EVM "perl $base/utils/EVM.merge.cmd.pl 03.gene_predict/04.evm/evm_for_each_chr $config{EVM} > 03.gene_predict/04.evm/04.merge.sh\n";
    print EVM "parallel -j $config{threads} < 03.gene_predict/04.evm/04.merge.sh\n";
    close EVM;
    
    print "!!!Step 2: Creating gene annotation cmd done. Just running sh 03.gene_predict*sh according the orders\n";
}else{
    die "wrong step number\n";
}


sub print_help{
    print STDERR<<EOF;
    
gene annotation pipeline, version: gene_annot_lzu_v2

Usage: perl gene_predict.pl --config <config file> --step <number of running>
  
Options:
--config    giving the config file with all needed things
--step      1 represent running repeat only; 2 represent running gene prediction only.
EOF
}
sub read_conf{
    my %r;
    $config=abs_path($config);
    open (TF,"$config") || die "no such file: $config\n";
    while (<TF>) {
        chomp;
        next if /^#/;
        next if /^\s*$/;
        next unless $_=~/^(\S+)\s+=\s+(\S+)/;
	$_=~/^(\S+)\s+=\s+(\S+)/;
        $r{$1}=$2;
    }
    close TF;
    return %r;
}


