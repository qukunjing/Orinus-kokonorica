# 1.Interproscan
interproscan.sh -f tsv -i Oko.pep.fa -o Oko.pep.fa.out.tsv -iprlookup -goterms -pa -t p
# 2.uniprot_sprot
blastp -db uniprot_sprot.fasta -query Oko.pep.fa -out Oko.swiss_sprot.out -evalue 1e-5 -outfmt 7 -num_threads 30
# 3.KOG
blastp -db kog -query Oko.pep.fa -out Oko.kog.out -evalue 1e-5 -outfmt 6 -num_threads 30
# 4.NR
diamond blastp --db /data/01/user112/database/nr/nr -q Oko.pep.fa -o nr.diamod.out
# 5.GO and KEGG
    1. Upload to "http://eggnog-mapper.embl.de" to get "out.emapper.annotations" file
    2. Donwload http://purl.obolibrary.org/obo/go/go-basic.obo
    python3 00.parse_go_obofile.py -i go-basic.obo -o go.tb
    python3 01.parse_eggNOG.py -i out.emapper.annotations -g go.tb -O ath,osa -o ./

# 6.Integration
cat Oko.pep.fa.out.tsv Oko.swiss_sprot.out Oko.kog.out nr.diamod.out kegg.out go.out >all.out
perl 02.rmrepeat.pl all.out >merge.fix.out