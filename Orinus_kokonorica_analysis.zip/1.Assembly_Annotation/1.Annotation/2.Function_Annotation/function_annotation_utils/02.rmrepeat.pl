use strict;
use warnings;

my %h;
my $in=shift;
open (F,"$in");
while (<F>) {
    chomp;
    next if /^#/;
    my @a=split(/\t/,$_);
    print join("\t",@a),"\n" if (! exists $h{$a[0]});
    $h{$a[0]}++;
}
close F;
